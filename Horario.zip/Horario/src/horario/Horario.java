
package horario;
import java.util.Scanner;
public class Horario {

    public static void main(String[] args) {
    hola ();
    }
    public static void hola (){
    Scanner h=new Scanner (System.in);
    Horario1 p=new Horario1 ();
    
    System.out.println ("1.lunes");
    System.out.println("2.martes");
    System.out.println("3.miercoles");
    System.out.println ("4.jueves");
    System.out.println ("5.viernes");
    System.out.println ("6.sabado");
    System.out.println ("7.domingo");
    
    
    System.out.println ("escribe el primer dia de la semana que tu buscas (tal como se muestra en la imagen sin los numeros y minusculas)");
    String horario=h.next();
    p.setHorario(horario);
    
    System.out.println ("inserte la cantidad de horas que transcurso (de 24 horas por favor)");
    int variable=h.nextInt();
    p.setVariable(variable);
     if (variable>24){
         System.out.println ("agrega un valor menos o igual a 24");
     }
    System.out.println ("inserte el valor del segundo dia");
    String horario1=h.next();
    p.setHorario1(horario1);
     
    System.out.println ("inserte la cantidad de horas transcurridad en el 2do dia");
    int variable1=h.nextInt();
    p.setVariable1(variable1);
      if (variable1>24){
          System.out.println ("agrega un valor menor o igual a 24");
      } 
    
      if (horario=="lunes" || horario=="martes" || horario=="miercoles" || horario=="jueves" || horario=="viernes" 
          || horario=="sabado" || horario=="domingo" || horario1=="lunes" || horario1=="martes" || horario1=="miercoles"
          || horario1=="jueves" || horario1=="viernes" || horario1=="sabado" || horario1=="domingo"    ){
         }
      else {
          System.out.println ("h");
      }
      }
     }
    



package horario;

import java.util.Scanner;
public class Horario1 {
    private String horario;
    private String horario1;
    private int variable;
    private int variable1;
    private int resultado; 
    
    public Horario1 (){}

    public Horario1(String horario, String horario1, int variable, int variable1, int resultado) {
        this.horario = horario;
        this.horario1 = horario1;
        this.variable = variable;
        this.variable1 = variable1;
        this.resultado = resultado;
    }

    @Override
    public String toString() {
        return "Horario1{" + "horario=" + horario + ", horario1=" + horario1 + ", variable=" + variable + ", variable1=" + variable1 + ", resultado=" + resultado + '}';
    }

    public int getResultado() {
        return resultado;
    }

    public void setResultado(int resultado) {
        this.resultado = resultado;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getHorario1() {
        return horario1;
    }

    public void setHorario1(String horario1) {
        this.horario1 = horario1;
    }

    public int getVariable() {
        return variable;
    }

    public void setVariable(int variable) {
        this.variable = variable;
    }

    public int getVariable1() {
        return variable1;
    }

    public void setVariable1(int variable1) {
        this.variable1 = variable1;
    }
    
    
}
